package pkm_data_installer;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class App {
    private static Yaml yaml = new Yaml();

    public static Map<String, Object> readYaml(String resourcePathString) {
        try(InputStream in = App.class.getClassLoader().getResourceAsStream(resourcePathString)){
            return yaml.load(in);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
            return null; // required to compile, but should never be reached
        }
    }

    public static void main(String[] args) {
        Map<String, Object> yamlMap = readYaml("pokemon-forms.yaml");
        try {
            Map<String, Object> bulbasaurMap = (Map<String, Object>)yamlMap.get("bulbasaur");
            Map<String, Object> statsMap = (Map<String, Object>)bulbasaurMap.get("stats");
            Integer hp = ((Integer)statsMap.getOrDefault("hp", null));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
